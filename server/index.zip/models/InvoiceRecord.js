import mongoose from "mongoose";

const InvoiceSchema = new mongoose.Schema(
  {
    purchaseOrderId: { type: String, required: true },
    orderNumber: { type: String, required: true },
    customerName: { type: String, required: true },
    customerAddress: { type: String, required: true },
    customerContact: { type: String, required: true },
    dueDate: { type: Date, required: true },
    totalAmount: { type: Number, required: true },
    status: {
      type: String,
      enum: ["Pending", "To review", "Closed"],
      
    },
    items: [
      {
        itemName: { type: String, required: true },
        quantity: { type: Number, required: true },
        price: { type: Number, required: true },
      },
    ],
  },
  { timestamps: true }
);

export default mongoose.model("InvoiceRecord", InvoiceSchema);
