import express from "express";
import {
  createInvoice,
  getInvoices,
  getInvoiceById,
  updateInvoice,
  deleteInvoice,
} from "../controllers/invoiceController.js";
import { serviceVerifyToken } from "../middleware/auth.js";

const router = express.Router();

// Create a new invoice
router.post("/", serviceVerifyToken, createInvoice);

// Get all invoices
router.get("/", getInvoices);

// Get a single invoice by ID
router.get("/:id", getInvoiceById);

// Update an invoice (protected route)
router.put("/:id", updateInvoice);

// Delete an invoice (protected route)
router.delete("/:id", deleteInvoice);

export default router;
